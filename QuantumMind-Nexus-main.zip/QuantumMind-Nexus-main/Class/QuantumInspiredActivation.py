import numpy as np

class QuantumInspiredActivation:
    def __init__(self):
        pass
    
    def forward(self, inputs):
        return np.sin(inputs)
